package Factory_Method.notificaciones;

// Notificacion.java
public interface Notificacion {
    void enviar(String mensaje);
}